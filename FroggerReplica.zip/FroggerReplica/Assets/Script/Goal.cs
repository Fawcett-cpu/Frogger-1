using UnityEngine;
using UnityEngine.SceneManagement;

public class Goal : MonoBehaviour {

	void OnTriggerEnter2D ()
	{
		Debug.Log("Next Level");
		SceneManager.LoadScene(SceneManager.GetActiveScene().name);
	}

}
