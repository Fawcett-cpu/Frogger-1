using UnityEngine;

public class ShipSpawner : MonoBehaviour {

	public float spawnDelay = 0.3f;

	public GameObject warrior2;

	public Transform[] spawnPoints;

	float nextTimeToSpawn = 0.2f;

	void Update ()
	{
		if (nextTimeToSpawn <= Time.time)
		{
			SpawnCar();
			nextTimeToSpawn = Time.time + spawnDelay;
		}
	}

	void SpawnCar ()
	{
		int randomIndex = Random.Range(0, spawnPoints.Length);
		Transform spawnPoint = spawnPoints[randomIndex];

		Instantiate(warrior2, spawnPoint.position, spawnPoint.rotation);
	}

}
