using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    public int CollectableScore = 0;
    public Text scoreText;

    void Start ()
    {
        scoreText.text = CollectableScore.ToString();
    }

    public void AddCoins(int collectableValue)
    {
        CollectableScore += collectableValue;
    }
}